logger.setTitle("EasyBackuper")
logger.logger("Hello World!")
logger.logger("Hello World!")
logger.logger("Hello World!")