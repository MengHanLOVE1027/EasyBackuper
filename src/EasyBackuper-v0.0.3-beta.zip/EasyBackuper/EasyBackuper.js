logger.setTitle("EasyBackuper")
logger.log("Hello World!")
logger.log("Hello World!")
logger.log("Hello World!")